import { Component, OnInit } from '@angular/core';
import { OAuthService } from 'angular-oauth2-oidc';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
    selector: 'app-message',
    template: `
        <h1>Message</h1>
        <div *ngIf="messages.length > 0">
        <li *ngFor="let message of messages">{{message}}</li>
        </div>
    `,
    styleUrls: ['./app.component.css']
})
export class MessageComponent  implements OnInit {
    messages: Array<any>[];

    constructor(private authService: OAuthService, private http: HttpClient) {
        this.messages = [];
    }

    async ngOnInit() {
        const accessToken = await this.authService.getAccessToken();
        const headers = new HttpHeaders({
            "Accept": "application/json",
            Authorization: 'Bearer ' + accessToken
        });
        // Make request
        this.http.get(
            'http://localhost:22241/api/messages',
            { headers: headers }
        )
            .subscribe((items: Array<any>) => items.forEach(item => this.messages.push(item)));
    }
}
