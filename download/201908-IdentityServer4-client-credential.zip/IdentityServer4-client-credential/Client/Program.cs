﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using IdentityModel.Client;
using Newtonsoft.Json.Linq;

namespace Client
{
    public class Program
    {
        static async Task Main()
        {
            // discover endpoints from metadata
            Console.WriteLine("get endpoint");
            var client = new HttpClient();
            var metadata = await client.GetDiscoveryDocumentAsync("http://localhost:5000");
            if (metadata.IsError)
            {
                Console.WriteLine(metadata.Error);
                return;
            }
            Console.WriteLine(metadata.TokenEndpoint);
            Console.WriteLine("\n\n");

            // get token
            Console.WriteLine("get access token");
            var tokenResponse = await client.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest()
            {
                Address = metadata.TokenEndpoint,
                ClientId = "client1",
                ClientSecret = "secret1",
                Scope = "empApi",
            });

            if (tokenResponse.IsError)
            {
                Console.WriteLine(tokenResponse.Error);
                return;
            }
            Console.WriteLine(tokenResponse.Json);
            Console.WriteLine("\n\n");

            // call api
            Console.WriteLine("get api resource");
            var apiClient = new HttpClient();
            apiClient.SetBearerToken(tokenResponse.AccessToken);
            var apiResponse = await apiClient.GetAsync("http://localhost:5002/identity");
            if (!apiResponse.IsSuccessStatusCode)
            {
                Console.WriteLine(apiResponse.StatusCode);
                return;
            }
            var content = await apiResponse.Content.ReadAsStringAsync();
            Console.WriteLine(JArray.Parse(content));
        }
    }
}
