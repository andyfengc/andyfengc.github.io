import { AfterContentChecked, AfterContentInit, EventEmitter, Input, Output } from "@angular/core";
import { Component, OnInit } from "@angular/core";
import { Model } from "./model";

@Component({
    selector: 'b-comp',
    template: `
    <div style="border: 1px solid red">
        <h2>I am text in child component - b</h2>
        {{model | json}}
        <c-comp [model]="model"></c-comp>
    <div>
    `
})
export class BComponent implements OnInit, AfterContentInit, AfterContentChecked {
    private _model = new Model();

    @Input() set model(val: Model) {
        console.log('set model in b');
        this._model = val;
    }
    get model() {
        console.log('get model in b');
        return this._model;
    }

    @Output() toResetted : EventEmitter<Date> = new EventEmitter<Date>();

    constructor() {
    }

    ngAfterContentInit(): void {
    }

    ngAfterContentChecked(): void {
    }

    ngOnInit() {
        //this._model.Name = "Child";
        //this._model.To = new Date(2021, 1, 1); // might cause issue
    }

}