import { Component, Input, OnInit } from "@angular/core";
import { Model } from "./model";

@Component({
    selector: 'a-comp',
    template: `
        <div style="border: 1px solid red">
            <h1>I am text in parent component </h1>
            {{model | json}}
            <b-comp [model]="model"></b-comp>
            <b3-comp [props]="model" (toChanged)="model.To = $event"></b3-comp>
            </div>        
    `
})
export class AComponent implements OnInit {
    private _model = new Model();

    @Input() set model(val: Model) {
        console.log('set model in a');
        this._model = val;
    } 
    get model() {
        console.log('get model in a');
        return this._model;
    }
    
    constructor() {
    }

    ngOnInit() {
        this._model.Name = "Parent";        
        //this._model.To = new Date(2021, 1, 1); // might cause issue
    }
}
