import { EventEmitter, Input, Output } from "@angular/core";
import { Component, OnInit } from "@angular/core";
import { Model } from "./model";

@Component({
    selector: 'c-comp',
    template: `
    <div style="border: 1px solid red">
        <h3>I am text in grandchild component</h3>
        {{model | json}}
    <div>
    `
})
export class CComponent implements OnInit {
    private _model = new Model();

    @Input() set model(val: Model) {
        console.log('set model in c');
        this._model = val;
    }
    get model() {
        console.log('get model in c');
        return this._model;
    }

    constructor() {
    }

    ngOnInit() {
        //this._model.Name = "Grandchild";
        //this._model.To = new Date(2021, 1, 1); // might cause issue
    }

}