import { AfterContentChecked, AfterContentInit, EventEmitter, Input, Output } from "@angular/core";
import { Component, OnInit } from "@angular/core";
import { Model } from "./model";

@Component({
    selector: 'b3-comp',
    template: `
    <div style="border: 1px solid red">
        <h2>I am text in child component - b3</h2>
        {{state | json}}
        <c-comp [model]="state"></c-comp>
    <div>
    `
})
export class B3Component implements OnInit, AfterContentInit, AfterContentChecked {
    private _props: Model;
    private _model = new Model();
    @Output() toChanged: EventEmitter<Date> = new EventEmitter<Date>();

    @Input() set props(val: Model) {
        this._props = val;
        this.state = this._props;
    }

    set state(val: Model) {
        console.log('set model in b');
        this._model = new Model(val);
    }
    get state() {
        console.log('get model in b');
        return this._model;
    }

    constructor() {
    }

    ngAfterContentInit(): void {
    }

    ngAfterContentChecked(): void {
    }

    ngOnInit() {
    }

    changeTo(val : Date){
        this._model.To = val
        this.toChanged.emit(new Date(2021, 1, 1));
    }

}