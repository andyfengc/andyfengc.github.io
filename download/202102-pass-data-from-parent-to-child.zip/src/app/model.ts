export class Model {
    constructor(model : Model = null){
        if (!model) return;
        this.Id = model.Id;
        this.Name = model.Name;
        this.From = model.From;
        this.To = model.To;
        this.Comment = model.Comment;
    }
    public Id : number;
    public Name: string;
    public From: Date;
    public To: Date;
    public Comment : string;
}