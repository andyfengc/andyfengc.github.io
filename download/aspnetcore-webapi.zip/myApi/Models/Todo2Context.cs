using Microsoft.EntityFrameworkCore;

namespace TodoApi.Models
{
    public class Todo2Context : DbContext
    {
        public Todo2Context(DbContextOptions<Todo2Context> options)
            : base(options)
        {
        }

        public DbSet<TodoItem> TodoItems { get; set; }

    }
}