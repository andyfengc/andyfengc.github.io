﻿using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

namespace WebHosting
{
    //[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class WebHost2 : ISampleWcfService
    {
        private SampleWcfService service;
        public WebHost2()
        {
            this.service = new SampleWcfService();
        }
        public Student GetStudent()
        {
            return this.service.GetStudent();
        }
    }
}
