﻿using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ConsoleHosting
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var host = new ServiceHost(typeof(SampleWcfService)))
            {
                host.Open();
                Console.WriteLine("host started");
                Console.ReadLine();
            }
        }
    }
}
