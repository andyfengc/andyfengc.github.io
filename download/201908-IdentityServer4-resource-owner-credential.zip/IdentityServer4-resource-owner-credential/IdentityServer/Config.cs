﻿using IdentityServer4.Models;
using IdentityServer4.Test;
using System.Collections.Generic;

namespace IdentityServer
{
    public static class Config
    {
        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new IdentityResource[]
            {
                new IdentityResources.OpenId()
            };
        }

        public static IEnumerable<ApiResource> GetApis()
        {
            //return new ApiResource[] { };
            return new List<ApiResource>
            {
                new ApiResource("empApi", "employee"),
                new ApiResource("custApi", "customer"),
                new ApiResource("prdApi", "product"),
            };
        }

        public static IEnumerable<Client> GetClients()
        {
            //return new Client[] { };
            return new List<Client>
            {
                new Client
                {
                    ClientId = "client1",

                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,

                    // secret for authentication
                    ClientSecrets =
                    {
                        new Secret("secret1".Sha256())
                    },

                    // scopes that client has access to
                    AllowedScopes = { "empApi" }
                },
                new Client
                {
                    ClientId = "client2",

                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,

                    // secret for authentication
                    ClientSecrets =
                    {
                        new Secret("secret2".Sha256())
                    },

                    // scopes that client has access to
                    AllowedScopes = { "custApi" }
                },
                new Client
                {
                    ClientId = "client3",

                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,

                    // secret for authentication
                    ClientSecrets =
                    {
                        new Secret("secret3".Sha256())
                    },

                    // scopes that client has access to
                    AllowedScopes = { "prdApi" }
                }
            };
        }

        public static List<TestUser> GetUsers()
        {
            return new List<TestUser>
            {
                new TestUser
                {
                    SubjectId = "1",
                    Username = "alice",
                    Password = "password"
                },
                new TestUser
                {
                    SubjectId = "2",
                    Username = "bob",
                    Password = "password"
                }
            };
        }
    }

}