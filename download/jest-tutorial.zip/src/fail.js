module.exports = {
    sum : function(a, b) {
      throw new Error('sum fails');
    }
};
