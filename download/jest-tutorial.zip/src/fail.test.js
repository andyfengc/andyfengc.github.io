const fail = require('./fail');

test('sum should fail', () => {
    expect(function(){fail.sum(1, 2)}).toThrow();
    expect(function(){fail.sum(1, 2)}).toThrow(Error);
});